from flask import Flask, render_template, request, redirect, url_for, session, jsonify
import datetime
import random

app = Flask(__name__)
app.secret_key = 'secret-key-for-session'

# In-memory storage
task_list = []

# Predefined content
jokes = [
    "Why don’t scientists trust atoms? Because they make up everything!",
    "Why did the computer go to therapy? It had too many bytes of sadness.",
    "I told my computer I needed a break, and now it won’t stop sending me beach wallpapers."
]

quotes = [
    "Believe in yourself and all that you are.",
    "Push yourself, because no one else is going to do it for you.",
    "Success is the sum of small efforts repeated day in and day out."
]

songs = [
    "🎵 'Espresso' - Sabrina Carpenter",
    "🎵 'Lose Control' - Teddy Swims",
    "🎵 'I Had Some Help' - Post Malone & Morgan Wallen"
]

weather_responses = {
    "delhi": "☀️ Delhi is sunny and warm at 35°C.",
    "mumbai": "🌧️ Mumbai is rainy and humid at 29°C.",
    "new york": "⛅ New York is cloudy at 22°C.",
    "default": "❓ Please specify a known city like Delhi, Mumbai, or New York."
}

facts = [
    "💡 Honey never spoils. Archaeologists have found pots of it in ancient tombs!",
    "💡 Octopuses have three hearts and blue blood.",
    "💡 A day on Venus is longer than a year on Venus."
]

motivations = [
    "🚀 Keep going! Great things take time.",
    "🌟 You're capable of amazing things.",
    "🔥 Small progress is still progress."
]

capitals = {
    "india": "🇮🇳 The capital of India is New Delhi.",
    "usa": "🇺🇸 The capital of USA is Washington, D.C.",
    "france": "🇫🇷 The capital of France is Paris.",
    "japan": "🇯🇵 The capital of Japan is Tokyo."
}

ai_one_liners = [
    "🤖 I’m not human, but I try my best to understand.",
    "💬 I dream in ones and zeros.",
    "⚙️ My favorite food is RAM—Random Access Memory."
]


# ------------------------- Chatbot Logic -------------------------
def get_bot_response(user_input):
    user_input = user_input.lower()

    if any(greet in user_input for greet in ["hello", "hi", "hey"]):
        return f"Hey {session.get('username', 'there')}! I’m your smart assistant. Ask me anything: time, joke, quote, song, fact, task, weather, or help."

    elif "your name" in user_input:
        return "🤖 I'm ChatGenie, your friendly assistant bot."

    elif "my name" in user_input:
        return f"👤 Your name is {session.get('username', 'User')}."

    elif "time" in user_input or "date" in user_input:
        now = datetime.datetime.now()
        return f"🕒 It's currently {now.strftime('%A, %d %B %Y - %I:%M %p')}."

    elif "joke" in user_input:
        return random.choice(jokes)

    elif "quote" in user_input or "motivation" in user_input:
        return random.choice(quotes + motivations)

    elif "trending song" in user_input or "top song" in user_input:
        return random.choice(songs)

    elif "weather" in user_input:
        for city in weather_responses:
            if city in user_input:
                return weather_responses[city]
        return weather_responses["default"]

    elif "capital of" in user_input:
        for country in capitals:
            if country in user_input:
                return capitals[country]
        return "🌍 I don't know that one yet. Try asking for India, USA, Japan, or France."

    elif "add task" in user_input:
        task = user_input.replace("add task", "").strip()
        if task:
            task_list.append(task)
            return f"✅ Task added: {task}"
        return "❗ Please specify the task."

    elif "list tasks" in user_input:
        if task_list:
            return "📝 Your tasks:\n" + "\n".join(f"- {task}" for task in task_list)
        return "🧾 You currently have no tasks."

    elif "fact" in user_input:
        return random.choice(facts)

    elif "ai" in user_input and "say" in user_input:
        return random.choice(ai_one_liners)

    elif "calculate" in user_input:
        try:
            expr = user_input.replace("calculate", "").strip()
            result = eval(expr)
            return f"🧮 The result is {result}"
        except:
            return "⚠️ Sorry, I couldn’t calculate that."

    elif "help" in user_input:
        return (
            "🛠️ Here’s what I can help with:\n"
            "- 📅 Time/Date: 'What's the time?'\n"
            "- 🎭 Jokes: 'Tell me a joke'\n"
            "- 💬 Quotes: 'Give me a quote'\n"
            "- 🎵 Songs: 'Trending song'\n"
            "- 🌦️ Weather: 'Weather in Delhi'\n"
            "- 📝 Tasks: 'Add task buy milk' or 'List tasks'\n"
            "- 💡 Fun facts: 'Tell me a fact'\n"
            "- 🧮 Math: 'Calculate 5 + 6*2'\n"
            "- 🗺️ Country capitals: 'Capital of Japan'\n"
            "- 👋 Say hi or bye anytime!"
        )

    elif "bye" in user_input:
        return "👋 Bye! Come back soon."

    else:
        return "🤔 I didn’t get that. Type 'help' to see what I can do."


# ------------------------- Routes -------------------------
@app.route('/')
def home():
    return render_template('index.html')


@app.route('/login', methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username")
        if username:
            session["username"] = username
            return redirect(url_for('chat'))
    return render_template('login.html')


@app.route('/chat')
def chat():
    if "username" not in session:
        return redirect(url_for("login"))
    return render_template('chatbot.html', username=session["username"])


@app.route('/logout')
def logout():
    session.pop("username", None)
    return redirect(url_for("home"))


@app.route('/get')
def get_response():
    if "username" not in session:
        return jsonify("Please log in.")
    msg = request.args.get("msg")
    return jsonify(get_bot_response(msg))


# ------------------------- Run App -------------------------
if __name__ == '__main__':
    app.run(debug=True)
