import math

def minimax(board, depth, maximizing, ai_letter, human_letter):
    if board.winner(ai_letter):
        return 1
    elif board.winner(human_letter):
        return -1
    elif board.is_full():
        return 0

    if maximizing:
        best = -math.inf
        for move in board.available_moves():
            board.make_move(move, ai_letter)
            score = minimax(board, depth + 1, False, ai_letter, human_letter)
            board.board[move] = " "
            best = max(score, best)
        return best
    else:
        best = math.inf
        for move in board.available_moves():
            board.make_move(move, human_letter)
            score = minimax(board, depth + 1, True, ai_letter, human_letter)
            board.board[move] = " "
            best = min(score, best)
        return best

def best_move(board, ai_letter, human_letter):
    best_score = -math.inf
    move = None
    for possible in board.available_moves():
        board.make_move(possible, ai_letter)
        score = minimax(board, 0, False, ai_letter, human_letter)
        board.board[possible] = " "
        if score > best_score:
            best_score = score
            move = possible
    return move
