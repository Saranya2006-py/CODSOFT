from flask import Flask, render_template, request, jsonify

# ✅ Flask app initialization
app = Flask(__name__)

# ✅ Home route
@app.route("/")
def home():
    return render_template("home.html")

# ✅ Game route
@app.route("/game")
def game():
    return render_template("game.html")

# ✅ Check for winner and return winning combo if found
def check_winner(board):
    winning_combos = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8],  # rows
        [0, 3, 6], [1, 4, 7], [2, 5, 8],  # columns
        [0, 4, 8], [2, 4, 6]             # diagonals
    ]
    for combo in winning_combos:
        a, b, c = combo
        if board[a] == board[b] == board[c] and board[a] != " ":
            return board[a], combo
    return None, None

# ✅ Minimax algorithm for AI (O is maximizing, X is minimizing)
def minimax(board, is_maximizing):
    winner, _ = check_winner(board)
    if winner == "X":
        return -1, None
    elif winner == "O":
        return 1, None
    elif " " not in board:
        return 0, None

    best_score = float("-inf") if is_maximizing else float("inf")
    best_move = None

    for i in range(9):
        if board[i] == " ":
            board[i] = "O" if is_maximizing else "X"
            score, _ = minimax(board, not is_maximizing)
            board[i] = " "
            if is_maximizing:
                if score > best_score:
                    best_score = score
                    best_move = i
            else:
                if score < best_score:
                    best_score = score
                    best_move = i

    return best_score, best_move

# ✅ /play API route
@app.route("/play", methods=["POST"])
def play():
    data = request.get_json()
    board = data["board"]

    # Check if player (X) already won
    winner, combo = check_winner(board)
    if winner:
        return jsonify(board=board, winner=winner, winning_combo=combo)
    elif " " not in board:
        return jsonify(board=board, draw=True)

    # AI move (O)
    _, move = minimax(board, True)
    if move is not None:
        board[move] = "O"

    # Check for AI win or draw
    winner, combo = check_winner(board)
    if winner:
        return jsonify(board=board, winner=winner, winning_combo=combo)
    elif " " not in board:
        return jsonify(board=board, draw=True)

    return jsonify(board=board)

# ✅ Run app
if __name__ == "__main__":
    app.run(debug=True)
